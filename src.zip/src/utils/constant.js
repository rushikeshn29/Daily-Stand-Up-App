export const PRESENT = "Present";
export const ABSENT = "Absent";
export const HOME = "Home";
export const OFFICE = "Office"
export const CLIENT_OFFICE = "Client Office";
