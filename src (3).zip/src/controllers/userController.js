import mongoose from "mongoose";
import userModel from "../models/userModel.js";
import { APIResponse } from "../utils/common.js";
import reportModel from "../models/reportModel.js";
import { ABSENT, PRESENT } from "../utils/constant.js";
import mailFieldsModel from "../models/mailFieldsModel.js";
import { sendEmail } from "../mail/sendMail.js";
import { DateFormatter } from "../utils/common.js";

export const addUserUpdates = async (req, res) => {
  try {
    const { id1, id2 } = req.params;
    const {
      attendance,
      workingStatus,
      workingOnClientName,
      workingFrom,
      updates,
      fromDate,
      toDate,
      reviewDate,
      pointsDiscussed,
      actionItems,
      blockersAndHeighlights
    } = req.body;

    const doc = new reportModel({
      userId: id1,
      teamLeadId: id2,
      attendance: attendance,
      workingStatus: workingOnClientName
        ? workingStatus + "-" + workingOnClientName
        : workingStatus,
      workingFrom: workingFrom,
      updates: updates,
      fromDate: fromDate,
      toDate: toDate,
      reviewDate: reviewDate,
    });

    const mailDoc = new mailFieldsModel({
      teamLeadId: id,
      blockersAndHeighlights: blockersAndHeighlights,
      actionItems: actionItems,
      pointsDiscussed: pointsDiscussed
    });

    const addUpdates = await doc.save();
    const addMailFields = await mailDoc.save();



    if (addUpdates && addMailFields) {


      const obj = {
        pointsDiscussed: addMailFields.pointsDiscussed,
        actionItems: addMailFields.actionItems,
        blockersAndHeighlights: addMailFields.blockersAndHeighlights

      }
      const finalResult = [...addUpdates, obj]
      res
        .status(201)
        .send(new APIResponse(1, "Updates added successfully...", finalResult));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error adding updates..."));
  }
};

export const updateUserUpdates = async (req, res) => {
  try {
    const id = req.params.id;
    const {
      attendance,
      workingStatus,
      workingOnClientName,
      workingFrom,
      updates,
      fromDate,
      toDate,
      reviewDate,
    } = req.body;
    const updateData = await reportModel
      .findByIdAndUpdate(
        id,
        {
          attendance: attendance,
          workingStatus: workingStatus + "-" + workingOnClientName,
          workingFrom: workingFrom,
          updates: updates,
          fromDate: fromDate,
          toDate: toDate,
          reviewDate: reviewDate,
        },
        { new: true }
      )
      .lean();
    if (updateData) {
      res
        .status(200)
        .send(new APIResponse(1, "Data updated successfully...", updateData));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error updating details"));
  }
};

export const deleteUserUpdates = async (req, res) => {
  try {
    const id = req.params.id;
    const deleteUpdates = await reportModel.findByIdAndDelete(id).lean();
    if (deleteUpdates) {
      res.status(200).send(new APIResponse(1, "Data deleted successfully..."));
    } else {
      res.status(400).send(new APIResponse(1, "Employee not found..."));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error deleting updates..."));
  }
};

export const getUserUpdates = async (req, res) => {
  try {
    const id = req.params.id;
    let start = new Date();
    start.setHours(0, 0, 0, 0);
    let end = new Date();
    end.setHours(23, 59, 59, 999);
    const getEmployeeUpdates = await reportModel
      .find({ userId: id, createdAt: { $gte: start, $lt: end } })
      .populate("userId")
      .lean();
    if (getEmployeeUpdates) {
      res
        .status(200)
        .send(new APIResponse(1, "Data found...", getEmployeeUpdates));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error fetching updates..."));
  }
};

export const getEmployeesOfTL = async (req, res) => {
  try {
    const id = req.params.id;

    const getEmployees = await userModel.find({ teamLeadId: id }).lean();
    if (getEmployees) {
      res.status(200).send(new APIResponse(1, "Data found...", getEmployees));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error fetching Records..."));
  }
};

export const getEmployeeDetailsById = async (req, res) => {
  try {
    const id = req.params.id;
    const userData = await userModel.findById(id).lean();
    if (userData) {
      res.status(200).send(new APIResponse(1, "Data found...", userData));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error fetching Records..."));
  }
};

export const getEmployeesTodaysUpdates = async (req, res) => {
  try {
    const id = req.params.id;
    let start = new Date();
    start.setHours(0, 0, 0, 0);
    let end = new Date();
    end.setHours(23, 59, 59, 999);
    const data = await reportModel
      .find({ teamLeadId: id, createdAt: { $gte: start, $lt: end } })
      .populate("userId")
      .lean();
    if (data) {
      res.status(200).send(new APIResponse(1, "Data found...", data));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error fetching updates..."));
  }
};

export const getUpdatesOfWeek = async (req, res) => {
  try {
    const id = req.params.id;
    const data = await reportModel
      .find({
        userId: id,
        createdAt: {
          $gte: new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000),
        },
      })
      .sort({ createdAt: -1 });
    if (data) {
      res.status(200).send(new APIResponse(1, "found data", data));
    }
  } catch (error) {
    res.status(400).send(new APIResponse(0, "Error while fetching data"));
  }
};

export const mailFields = async (req, res) => {
  try {
    const id = req.params.id;
    const { blockersAndHeighlights, actionItems, pointsDiscussed } = req.body;
    const doc = new mailFieldsModel({
      teamLeadId: id,
      blockersAndHeighlights: blockersAndHeighlights,
      actionItems: actionItems,
      pointsDiscussed: pointsDiscussed,
    });
    const addData = await doc.save();
    if (addData) {
      res
        .status(201)
        .send(new APIResponse(1, "Updates added successfully...", addData));
    }
  } catch (error) {
    console.log(error);
    res.status(400).send(new APIResponse(0, "Error adding updates..."));
  }
};

export const getTableData = async (req, res) => {
  try {
    const id = req.params.id;
    let start = new Date();
    start.setHours(0, 0, 0, 0);
    let end = new Date();
    end.setHours(23, 59, 59, 999);
    const getEmployeesOfTl = await userModel
      .find(
        { teamLeadId: id },
        { firstName: 1, lastName: 1, email: 1, employeeId: 1, teamLeadId: 1 }
      )
      .lean();

    const data = getEmployeesOfTl.map((item) => item._id);

    const daysPresent = await reportModel.aggregate([
      {
        $match: {
          teamLeadId: new mongoose.Types.ObjectId(`${id}`),
          attendance: PRESENT,
        },
      },
      {
        $group: { _id: "$userId", count: { $sum: 1 } },
      },
    ]);

    // console.log(daysPresent, "lll");

    for (let employee of getEmployeesOfTl) {
      for (let daysCount of daysPresent) {
        if (String(employee._id) == String(daysCount._id)) {
          employee.count = daysCount.count;
        }
      }
    }

    // console.log(getEmployeesOfTl);

    const report = await reportModel.aggregate([
      {
        $match: {
          $and: [
            { userId: { $in: data } }
          ],
        },
      },
    ]);

    // console.log(report, "report");

    for (let i1 of getEmployeesOfTl) {
      for (let i2 of report) {
        if (String(i1._id) === String(i2.userId)) {
          let date1 = DateFormatter(i2.createdAt)
          let date2 = DateFormatter(new Date())
          if (date1 == date2) {
            (i1.flag = true),
              (i1.workingFrom = i2.workingFrom),
              (i1.workingStatus = i2.workingStatus),
              (i1.workingOnClientName = i2.workingOnClientName),
              (i1.attendance = i2.attendance),
              (i1.updates = i2.updates);
            i1.toDate = i2.toDate;
            i1.fromDate = i2.fromDate;
            i1.reviewDate = i2.reviewDate;
          }
        } else {
          (i1.flag = false),
            (i1.workingFrom = ""),
            (i1.workingStatus = ""),
            (i1.workingOnClientName = ""),
            (i1.attendance = ""),
            (i1.updates = "");
          i1.toDate = "";
          i1.fromDate = "";
          i1.reviewDate = "";
        }
      }
    }

    const mailFieldsData = await mailFieldsModel.findOne({ teamLeadId: id, createdAt: { $gt: start, $lt: end } }).populate("teamLeadId");

    let obj;
    if (mailFieldsData.length > 0) {

      obj = {
        pointsDiscussed: mailFieldsData.pointsDiscussed,
        actionItems: mailFieldsData.actionItems,
        blockersAndHeighlights: mailFieldsData.blockersAndHeighlights
      }
    }
    else {
      obj = {
        pointsDiscussed: "",
        actionItems: "",
        blockersAndHeighlights: ""
      }

    }

    const finalResult = [...getEmployeesOfTl, obj];


    res.status(200).send(new APIResponse(1, "found data", finalResult));
  } catch (error) {
    console.log(error);
    res.status(400).send(new APIResponse(0, "Error while fetching data"));
  }
};

export const exportAllDataForExcel = async (req, res) => {
  try {
    const id = req.params.id;
    let start = new Date();
    start.setHours(0, 0, 0, 0);
    let end = new Date();
    end.setHours(23, 59, 59, 999);
    const getEmployeesOfTl = await userModel
      .find(
        { teamLeadId: id },
        { firstName: 1, lastName: 1, email: 1, teamLeadId: 1 }
      )
      .lean();

    const data = getEmployeesOfTl.map((item) => item._id);

    const daysPresent = await reportModel.aggregate([
      {
        $match: {
          teamLeadId: new mongoose.Types.ObjectId(`${id}`),
          attendance: PRESENT,
        },
      },
      {
        $group: { _id: "$userId", count: { $sum: 1 } },
      },
    ]);

    for (let employee of getEmployeesOfTl) {
      for (let daysCount of daysPresent) {
        if (String(employee._id) == String(daysCount._id)) {
          employee.count = daysCount.count;
        }
      }
    }

    const report = await reportModel.aggregate([
      {
        $match: {
          $and: [
            { userId: { $in: data } }
          ],
        },
      },
    ]);

    for (let i1 of getEmployeesOfTl) {
      for (let i2 of report) {
        if (String(i1._id) === String(i2.userId)) {
          let date1 = DateFormatter(i2.createdAt)
          let date2 = DateFormatter(new Date())
          if (date1 == date2) {
            (i1.flag = true),
              (i1.attendance = i2.attendance),
              (i1.workingFrom = i2.workingFrom),
              (i1.workingStatus = i2.workingStatus),
              (i1.updates = i2.updates);
            i1.toDate = i2.toDate;
            i1.fromDate = i2.fromDate;
            i1.reviewDate = i2.reviewDate;
          }
        } else {
          (i1.flag = false),
            (i1.workingFrom = ""),
            (i1.workingStatus = ""),
            (i1.attendance = ""),
            (i1.updates = "");
          i1.toDate = "";
          i1.fromDate = "";
          i1.reviewDate = "";
        }
      }
    }

    // console.log(getEmployeesOfTl);

    const mailFieldsData = await mailFieldsModel.findOne({ teamLeadId: id, createdAt: { $gt: start, $lt: end } }).populate("teamLeadId");

    const obj = {
      teamLeadIdName: mailFieldsData.teamLeadId.firstName + " " + mailFieldsData.teamLeadId.lastName,
      teamLeadIdEmail: mailFieldsData.teamLeadId.email,
      teamLeadIdDepartment: mailFieldsData.teamLeadId.department,
      teamLeadIdContactNumber: mailFieldsData.teamLeadId.contact,
      pointsDiscussed: mailFieldsData.pointsDiscussed,
      actionItems: mailFieldsData.actionItems,
      blockersAndHeighlights: mailFieldsData.blockersAndHeighlights
    }


    const finalResult = [...getEmployeesOfTl, obj];

    const mailNotify = await sendEmail(finalResult);
    if (mailNotify) {
      console.log("mail sent successfully");
    }

    res.status(200).send(new APIResponse(1, "Data found", finalResult));
  } catch (error) {
    console.log(error);
    res.status(400).send(new APIResponse(0, "Error while fetching data"));
  }
};
