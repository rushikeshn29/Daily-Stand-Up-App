import ejs from 'ejs';
import path from 'path';
import { __dirname } from "../index.js";
import transporter from "../config/emailConfig.js";
import { DateFormatter } from '../utils/common.js';


export const sendEmail = (data) => {

    // console.log(data, 'data');
    let nilesh = data?.pop();
    // console.log(nilesh, "nislesh");

    const filePath = path.join(__dirname, '/src/templates/dailyUpdates.ejs');
    ejs.renderFile(`${filePath}`, { data, nilesh }, (err, data) => {
        if (err) {
            console.log(err.message);
        } else {
            console.log(nilesh, "sayali");
            console.log(nilesh.teamLeadIdEmail, "email");
            var mailOptions = {
                from: nilesh.teamLeadIdEmail,
                to: "saurabhkute321@gmail.com",
                subject: `MOM - Daily Standup with Team - ${nilesh.teamLeadIdName} - - on ${DateFormatter(new Date)}`,
                html: data + nilesh
            };

            // console.log(mailOptions);

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    return console.log(error);
                }
                console.log('Message sent: %s', info.messageId);
            });
        }
    });
};